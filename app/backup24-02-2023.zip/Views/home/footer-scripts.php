
<!-- Vendor js -->
<script src="<?php echo base_url(); ?>/assets/js/vendor.min.js"></script>

<!-- Chart JS -->
<script src="<?php echo base_url(); ?>/assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="https://apexcharts.com/samples/assets/irregular-data-series.js"></script>
<script src="https://apexcharts.com/samples/assets/ohlc.js"></script>

<!-- App js-->
<script src="<?php echo base_url(); ?>/assets/js/app.min.js"></script>

<!-- Footable js -->
<script src="<?php echo base_url(); ?>/assets/libs/footable/footable.all.min.js"></script>

<!-- Init js -->
<script src="<?php echo base_url(); ?>/assets/js/pages/foo-tables.init.js"></script>

<!-- Dashboard init JS -->
<!-- <script src="<?php echo base_url(); ?>/assets/js/pages/dashboard-3.init.js"></script> -->

<!-- Dashboard 2 init -->
<!-- <script src="<?php echo base_url(); ?>/assets/js/pages/dashboard-2.init.js"></script> -->
