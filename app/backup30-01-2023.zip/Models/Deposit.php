<?php

namespace App\Models;

use CodeIgniter\Model;

class Deposit extends Model
{

    protected $table = 'deposit';
    protected $primaryKey = 'id';
    protected $allowedFields = [ 'user_id', 'currency_id', 'currency_option_id', 'amount', 'deposite_date', 'status', 'accepted_date', 'reject_reason', 'message', 'isDeleted', 'updatedAt', 'createdAt'];

    public function getdata()
    {
        return $this->orderby('id', 'desc')->findAll();
    }

    public function getAllDeposits(){
        $this->select('deposit.id, deposit.deposite_date, deposit.status, deposit.accepted_date,
         deposit.reject_reason, deposit.message, deposit.amount, C.name AS currency, CO.name AS currency_option, 
         U.firstName, U.lastName, U.profile_img');
        $this->join('currency AS C', 'C.id = deposit.currency_id', 'LEFT');
        $this->join('currency_option AS CO', 'CO.id = deposit.currency_option_id', 'LEFT');
        $this->join('users AS U', 'U.id = deposit.user_id', 'LEFT');
        $this->orderby('deposit.id', 'desc');
        $query = $this->findAll();
        return $query;
    }
    public function getDepositsbyid($id){
        $this->select('user_id');
        $this->where('id =', $id);
        $query = $this->find();
        return $query;
    }

    public function getAllDepositsByUserId($id){
        $this->select('deposit.deposite_date, deposit.status, deposit.accepted_date, deposit.message, deposit.reject_reason, deposit.amount, C.name AS currency, CO.name AS currency_option');
        $this->join('currency AS C', 'C.id = deposit.currency_id', 'LEFT');
        $this->join('currency_option AS CO', 'CO.id = deposit.currency_option_id', 'LEFT');
        $this->where('user_id =', $id);
        $this->orderby('deposit.id', 'desc');
        $query = $this->findAll();
        return $query;
    }

    public function getAcceptedDepositByUserId($id){
        $this->selectSum('amount');
        $this->where('status', "Completed");
        $this->where('user_id', $id);
        $query = $this->findAll();
        return $query[0]['amount'];
    }
    public function getCompletedDepositByUserId($id){
        $this->select('*');
        $this->where('status', "Completed");
        $this->where('user_id', $id);
        $query = $this->findAll();
        return $query;
    }
    public function getCompletedDepositByUserId_Overview($id){
        $this->select('*');
        $this->where('status', "Completed");
        $this->where('user_id', $id);
        $this->like('deposite_date' , '2022');
        $query = $this->findAll();
        return $query;
    }

}