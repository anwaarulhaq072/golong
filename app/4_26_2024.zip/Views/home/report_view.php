<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Report View - <?php echo APP_NAME ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Nvest Clients - Where you can invest" name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <script src="<?php echo base_url(); ?>/assets/js/html2canvas.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/jspdf.umd.min.js"></script>


    <?php echo view("/home/header-links"); ?>
    <style>
        .check_s{
            padding: 10px;
            font-size: 19px;
            text-align: center;
            color: black;
            border-style: solid;
            border-color: black;
            margin-left: 10px;
        }
        .hname{
            font-size: 30px;
            font-weight: bold;
            color: black;
            font-family: sans-serif;
        }
        .csname{
            font-size: 20px;
            font-weight: bold;
            color: black; 
            font-family: sans-serif;
        }
        .table_cla{
            color: black;
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 25px;
        }
        .table_div{
            padding-right: 50% !important;
            padding-left: 5% !important;
        }
        @media (max-width: 550px)
        {
            .hname{
            font-size: 18px;
        }
        .csname{
            font-size: 15px;
        }
        .hname2{
            margin: 0px !important;
        }
        .check_s{
            margin-left: 0px;
        }
        .table_div{
            padding-right: 0px !important;
        }
        }
    </style>

</head>

<!-- body start -->

<body class="loading" data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": false}, "topbar": {"color": "light"}}'>
    <!-- Begin page -->
    <div id="wrapper">
        <?php echo view("/home/left-sidebar"); ?>
        <!-- include Top-bar -->
        <?php echo view("/home/top-bar") ?>

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="content-page pt-4 col-lg-10 col-md-10" style=" background-color: #F5F5FC !important;">
        <button onclick="Convert_HTML_To_PDF();" style="margin-right:14px !important; float: right;" class="btn btn-primary waves-effect waves-light">Create PDF</button>
            <div class="content" style="margin-top: 50px;">
                <!-- Start Content-->
                                         <!-- Trigger button -->
                <div class="container-fluid">
                     <!-- Form row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Filter</h4>

                                <form id="deposit_form" action="<?php echo base_url(); ?>/user/report_genrate" method="POST">
                                        <div class="mb-3 col-md-6">
                                            <label for="select_client" class="form-label">Select Time</label>
                                            <select id="select_duration" class="form-select" name="select_duration">
                                                <option value="0">Choose</option>
                                                <option value="TM">This Month</option>
                                                <option value="LM">Last Month</option>
                                                <option value="L9D">Last 90 Days</option>
                                                <option value="CY">Current Year</option>
                                                <option value="Custom_date">Custom Date</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6" style="float: right; margin-top: -62px;">
                                        <button type="submit" style="margin-left:10px !important;" class="btn btn-primary waves-effect waves-light">Search</button>
                                        </div>
                                        <div class="row" id = "cutome_dates_input" style="display: none">
                                        <div class="mb-3 col-md-6">
                                        <label for="start_date" class="form-label">Start Date</label><br>
                                            <input type="date" class="form-control" id="start_date" name = "start_date" />
                                        </div>
                                        <div class="mb-3 col-md-6">
                                        <label for="start_date" class="form-label">End Date</label><br>
                                            <input type="date" class="form-control" id="end_date" name ="end_date" />
                                        </div>
                                        </div>

                                </form>


                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
                    <?php if(isset($userInfo) && isset($all_Data)): ?>
                <!-- end row -->
                    <h3 class="header-title mt-4 mb-3">Client's Report</h3>
                    <div class="row" id="contentToPrint" style="font-family: sans-serif;">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                        <div class="hname2 mb-5 col-md-7">
                                        <h2 class="hname"><img style="" src="<?php echo base_url(); ?>/assets/images/G_logo.png" alt="" height="200"></h2>
                                        <p style="color: black;margin-left: 50px;margin-top: -45px;">1435 FM 1463 Katy<br>TX 77494</p>
                                        </div>
                                        <div class="hname2 mt-5 col-md-5">
                                        <p style="font-size: 10px;font-weight: bold;color: black;"><?php if(isset($start_date) && isset($end_date)) echo $start_date." through ".$end_date; ?></p>
                                        <p style="font-size: 10px;font-weight: bold;color: black;">Primary Account:  00<?php echo $userInfo['id']; ?></p>
                                        </div>
                                        </div>
                                        <div class="row">
                                        <div class="hname2 mt-3 col-md-7">
                                        <p style="font-size: 10px;font-weight: bold;color: black;"><?php echo $userInfo['firstName']." ".$userInfo['lastName'] ?></p>
                                        <p style="font-size: 10px;font-weight: bold;color: black;"><?php echo $userInfo['email'] ?></p>
                                        <p style="font-size: 10px;font-weight: bold;color: black;"><?php echo $userInfo['phone'] ?></p>
                                        </div>
                                        <div class="hname2 mb-1 col-md-5">
                                        <hr style="color: black;height: 5px;">
                                        <h2 class = "hname2 csname">Customer Service Information</h2>
                                        <hr style="color: black;height: 5px;">
                                        <p style="font-size: 10px;font-weight: bold;color: black;">Service Center: CloudBaseApi</p>
                                        <p style="font-size: 10px;font-weight: bold;color: black;">Web Site: www.golongclients.com</p>
                                        </div>
                                        </div>
                                        <div class="row">
                                        <div class="mb-2 col-md-3 check_s" >
                                        CHECKING SUMMARY
                                        </div>
                                        <input type = "hidden" id="data_size" value="<?php if(isset($all_Data)) echo sizeof($all_Data) ?>">
                                        <div class="col-md-9" style="margin: 16px 0px 0px -12px;">
                                        <hr style="color: black;height: 2px;">
                                        </div>
                                        <div class="row table_div">
                                        <table class="table_cla">
                                            <tr>
                                                <td>Beginning Balance</td>
                                                <td style="text-align: end;"><?php echo '$'.$startAmount; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Deposits And Additions</td>
                                                <td style="text-align: end;"><?php echo "+".$depositSum + ($PSum-$LSum); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Withdrawals</td>
                                                <td style="text-align: end;"><?php echo "-".$withdrawSum + $payoutSum; ?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td><?php echo '<hr style="color: black;height: 5px;">'; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Ending Balance</td>
                                                <td style="text-align: end;"><?php echo '$'.$endAmount; ?></td>
                                            </tr>
                                        </table>
                                        </div>
                                        </div>
                                        <div class="row">
                                        <div class="mb-2 col-md-3 check_s" >
                                        TRANSACTION DETAIL
                                        </div>
                                        <div class="col-md-9" style="margin: 16px 0px 0px -12px;">
                                        <hr style="color: black;height: 2px;">
                                        </div>
                                        </div>
                                    <div class="table-responsive">
                                    <table id="" class="table toggle-circle mb-0" data-page-size="<?php echo sizeof($all_Data); ?>">
                                        <thead style="background-color: #F2F2F2;">
                                                <tr>
                                                    <!-- <th>Name</th> -->
                                                    <th>Date</th>
                                                    <!-- <th>Transition</th>
                                                    <th>Withdrawals</th>
                                                    <th>Deposits</th>
                                                    <th>Payout</th> -->
                                                    <th>Description</th>
                                                    <th>Amount</th>
                                                    <th>Balance</th>
                                                </tr>
                                            </thead>
                                        
                                        
                                            <tbody>
                                                <?php for($i = 0 ;$i<sizeof($all_Data);$i++): ?>
                                                <?php if($i == 0): ?>
                                                <tr> 
                                                    <td><?php if(isset($start_date)) $date = explode(" ",$start_date); echo date('m/d/y',strtotime($date[0])); ?></td>
                                                    <td> Starting Balance </td>
                                                    <td> - </td>
                                                    <td><?php if(isset($startAmount)) echo '$'.$startAmount?></td>
                                                    
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($all_Data[$i]['type'] != 'Swing'): ?>
                                                <tr> 
                                                    <!-- <td></td> -->
                                                    <td><?php if(isset($all_Data[$i]['date'])) $date = explode(" ",$all_Data[$i]['date']); echo date('m/d/y',strtotime($date[0])); ?></td>
                                                    <!-- <td>
                                                        <?php if (isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Profit') : ?>
                                                            <i class="fa fa-arrow-circle-up" aria-hidden="true" style="font-size: 23px; color: #1ABC9C;"></i> &nbsp; $<?php echo $all_Data[$i]['trasition']; ?>
                                                            <?php elseif(isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Loss') : ?>
                                                                <i class="fa fa-arrow-circle-down" aria-hidden="true" style="font-size: 23px; color: #D06162;"></i> &nbsp; $<?php echo $all_Data[$i]['trasition']; ?>
                                                                <?php elseif(isset($all_Data[$i]['type'])): ?>
                                                                    $<?php echo "(S)".$all_Data[$i]['trasition']; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                    <td><?php if(isset($all_Data[$i]['widthra'])) echo $all_Data[$i]['widthra'] ?></td>
                                                    <td><?php if(isset($all_Data[$i]['deposit'])) echo $all_Data[$i]['deposit'] ?></td>
                                                    <td><?php if(isset($all_Data[$i]['payout'])) echo $all_Data[$i]['payout'] ?></td> -->
                                                    <td><?php if(isset($all_Data[$i]['payout'])): echo 'Payout Sent To Client'; elseif(isset($all_Data[$i]['widthra'])): echo 'Amount Withdrawn By Client'; elseif(isset($all_Data[$i]['deposit'])): echo 'Amount Deposited By Client'; elseif(isset($all_Data[$i]['trasition'])): if (isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Profit'): echo 'Profit Added In Account'; elseif(isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Loss'): echo 'Loss Deduct From Account'; endif; endif;?></td>
                                                    <td><?php if(isset($all_Data[$i]['payout'])): echo '$'.$all_Data[$i]['payout']; elseif(isset($all_Data[$i]['widthra'])): echo '$'.$all_Data[$i]['widthra']; elseif(isset($all_Data[$i]['deposit'])): echo '$'.$all_Data[$i]['deposit']; elseif(isset($all_Data[$i]['trasition'])): if (isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Profit'): echo '$'.$all_Data[$i]['trasition']; elseif(isset($all_Data[$i]['type']) && $all_Data[$i]['type'] == 'Loss'): echo '$'.$all_Data[$i]['trasition']; endif; endif;?></td>
                                                    <td><?php if(isset($all_Data[$i]['balance'])) echo '$'.$all_Data[$i]['balance']?></td>
                                                    
                                                </tr>
                                                <?php endif; ?>
                                                <?php endfor ?>
                                            </tbody>
                                        </table>
                                    </div>
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->
    <?php echo view("/home/footer-scripts"); ?>
        <script>
            $("#select_duration").change(function(){
                if( $("#select_duration").val() == 'Custom_date'){
                $('#cutome_dates_input').css("display", "block");
                }else{
                    $('#cutome_dates_input').css("display", "none");
                }
                
                });
                window.jsPDF = window.jspdf.jsPDF;

                // Convert HTML content to PDF
                function Convert_HTML_To_PDF() {
                    var size = document.getElementById("data_size").value;
                    var doc = new jsPDF("pl","mm");
                    
                    // Source HTMLElement or a string containing HTML.
                    var elementHTML = document.querySelector("#contentToPrint");
                    doc.html(elementHTML, {
                        callback: function(doc) {
                            // Save the PDF
                            var pageCount = doc.internal.getNumberOfPages();
                        if(size < 10){
                            for(var i = pageCount;i>2 ;i--){
                            doc.deletePage(i);
                            }
                        }else if(size >= 10 && size <= 30){
                            for(var i = pageCount;i>2 ;i--){
                            doc.deletePage(i);
                            }
                        }else if(size >= 30 && size <= 50){
                            for(var i = pageCount;i>3 ;i--){
                            doc.deletePage(i);
                            }
                        }else if(size >= 50 && size <= 70){
                            for(var i = pageCount;i>4 ;i--){
                            doc.deletePage(i);
                            }
                        }else if(size >= 70 && size <= 70){
                            for(var i = pageCount;i>5 ;i--){
                            doc.deletePage(i);
                            }
                        }else if(size >= 90 && size <= 110){
                            for(var i = pageCount;i>6 ;i--){
                            doc.deletePage(i);
                            }
                        }
                            doc.save('Report.pdf');
                        },
                        margin: [10, 10, 10, 10],
                        autoPaging: 'text',
                        x: 0,
                        y: 0,
                        width: 190, //target width in the PDF document
                        windowWidth: 675, //window width in CSS pixels
                    });
                }
        </script>
</body>

</html>