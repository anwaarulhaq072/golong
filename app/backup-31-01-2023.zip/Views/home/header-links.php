
 <!-- App favicon -->
 <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets/images/favicon.png">

<!-- App css -->
<link href="<?php echo base_url(); ?>/assets/css/config/default/bootstrap.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
<link href="<?php echo base_url(); ?>/assets/css/config/default/app.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />

<!-- plugin css -->
<link href="<?php echo base_url(); ?>/assets/css/config/default/bootstrap-dark.min.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
<link href="<?php echo base_url(); ?>/assets/css/config/default/app-dark.min.css" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />
<script src="https://www.gstatic.com/firebasejs/8.2.2/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.2/firebase-messaging.js"></script>
<!-- icons -->
<link href="<?php echo base_url(); ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<script>
    const firebaseConfig = {
        apiKey: "AIzaSyCUm5YstkPOVFrTQc6o2hZapMoHIs1Xu8c",
        authDomain: "golong-a9f80.firebaseapp.com",
        projectId: "golong-a9f80",
        storageBucket: "golong-a9f80.appspot.com",
        messagingSenderId: "478342696383",
        appId: "1:478342696383:web:ecbd6ea04173185e0d250a",
        measurementId: "G-5Y2EDPRZ2M"
    };
    firebase.initializeApp(firebaseConfig);

    const fcm = firebase.messaging();
    fcm.getToken({
        vapidkey: 'BNCB1JiZQsmEfvRP9PJ0xyTMZ-pjkYK-X7apLpFOekF1iClIFQMTufbXy_YziRJ7AFkNNEqN8EgKLIETnbBvbF8' 
    }).then((token)=>{
        console.log('TOken: => ' , token)
    })
</script>
<style>
    .card {
        box-shadow: 0px 0px 20px rgb(0 0 0 / 20%);
        border-radius: 0.5rem;
    }
    .primary_btn{
        background-color: rgba(0, 115, 182, 0.15);
        padding: 7px 10px;
        border: 1px solid #0073B6;
        border-radius: 5px;
        color: #000000;
    }
    .footable-pagination li.active a {
            color: #000;
            background-color: rgba(0, 115, 182, 0.15);
            border-color: #0073B6;
        }
</style>